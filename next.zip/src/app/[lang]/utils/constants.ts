export const FALLBACK_SEO = {
  title: "RCCG Providence Court",
  description: "Welcome to RCCG Providence Court",
};
