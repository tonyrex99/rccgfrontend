import Loader from './components/Loader';

export default function RootLoading() {
    return <Loader />;
}
