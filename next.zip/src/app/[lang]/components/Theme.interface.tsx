export interface Theme {
  PrimaryColor: string;
  SecondaryColor: string;
  // Add other theme properties if needed
}
