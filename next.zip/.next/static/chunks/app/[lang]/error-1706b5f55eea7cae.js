(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[450],{1550:function(r,e,n){Promise.resolve().then(n.bind(n,1121))},1121:function(r,e,n){"use strict";n.r(e),n.d(e,{default:function(){return RootErrorBoundary}});var o=n(7437);function Error(){return(0,o.jsx)("div",{className:"container mx-auto p-8",children:(0,o.jsx)("h2",{children:"Something went wrong!"})})}function RootErrorBoundary(){return(0,o.jsx)(Error,{})}},622:function(r,e,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var o=n(2265),t=Symbol.for("react.element"),u=Symbol.for("react.fragment"),s=Object.prototype.hasOwnProperty,f=o.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,i={key:!0,ref:!0,__self:!0,__source:!0};function q(r,e,n){var o,u={},c=null,a=null;for(o in void 0!==n&&(c=""+n),void 0!==e.key&&(c=""+e.key),void 0!==e.ref&&(a=e.ref),e)s.call(e,o)&&!i.hasOwnProperty(o)&&(u[o]=e[o]);if(r&&r.defaultProps)for(o in e=r.defaultProps)void 0===u[o]&&(u[o]=e[o]);return{$$typeof:t,type:r,key:c,ref:a,props:u,_owner:f.current}}e.Fragment=u,e.jsx=q,e.jsxs=q},7437:function(r,e,n){"use strict";r.exports=n(622)}},function(r){r.O(0,[971,472,744],function(){return r(r.s=1550)}),_N_E=r.O()}]);